package gameplay;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import humans.Vendor;
import locations.Concessions;
import locations.Store;
import locations.TeamStore;
import locations.Ticketbooth;

public class Club implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 845228950378337142L;
	Team team;
	String stadium;
	ArrayList<Team> opponents;
	ArrayList<Game> schedule;
	ArrayList<Store> stores;
	double profit;
	Game currGame = null;
	
	public Club() {
		team = new Team();
		stadium = "";
		opponents = new ArrayList<Team>();
		schedule = new ArrayList<Game>();
		stores = new ArrayList<Store>();
		stores.add(new Ticketbooth());
		stores.add(new TeamStore());
		stores.add(new Concessions());
		profit = 0;
		currGame = null;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	public String getStadium() {
		return stadium;
	}

	public void setStadium(String stadium) {
		this.stadium = stadium;
	}

	public ArrayList<Team> getOpponents() {
		return opponents;
	}

	public void setOpponents(ArrayList<Team> opponents) {
		this.opponents = opponents;
	}

	public ArrayList<Game> getSchedule() {
		return schedule;
	}

	public void setSchedule(ArrayList<Game> schedule) {
		this.schedule = schedule;
	}

	public ArrayList<Store> getStores() {
		return stores;
	}

	public void setStores(ArrayList<Store> stores) {
		this.stores = stores;
	}

	public double getProfit() {
		return profit;
	}

	public void setProfit(double profit) {
		this.profit = profit;
	}
	
	public Game getCurrGame() {
		return currGame;
	}
	
	public void scheduleGame(Game aGame) throws Exception {
		if(!opponents.contains(aGame.getAwayTeam())) {
			throw new Exception("TeamNotFound");
		}
		
		if( ((aGame.getSchedule()/100) > 31) || (aGame.getSchedule() < 0) ) {
			throw new Exception("InvalidDate");
		}
		
		if((aGame.getSchedule() % 100) > 23) {
			throw new Exception("InvalidTime");
		}
		
		for(int i = 0; i < schedule.size(); i++) {
			if((aGame.getSchedule()/100) == (schedule.get(i).getSchedule()/100)) {
				throw new Exception("GameAlreadyScheduled");
			}
			
			if(aGame.getSchedule() < schedule.get(i).getSchedule()) {
				schedule.add(i, aGame);
				return;
			}
		}
		schedule.add(aGame);
		
	}
	
	public void restock() {
		for(int i = 0; i < stores.size(); i++) {
			stores.get(i).restock();
		}
	}
	
	public double calculateCosts() {
		double money = 0;
		for(int i = 0; i < stores.size(); i++) {
			money += stores.get(i).getCosts();
			stores.get(i).setCosts(0);
			
			ArrayList<Vendor> vendorRoster = stores.get(i).getWorkers();
			for(int j = 0; j < vendorRoster.size(); j++) {
				money += vendorRoster.get(i).getWage() * 4;
			}
		}
		
		money += team.calculateCosts();
		
		return money;
	}
	
	public double calculateRevenue() {
		double money = 0;
		for(int i = 0; i < stores.size(); i++) {
			money += stores.get(i).getRevenue();
			stores.get(i).setRevenue(0);
		}
		
		return money;
	}
	
	public double calculateProfit() {
		profit += calculateRevenue() - calculateCosts();
		return profit;
	}
	
	public void startGame() throws Exception{
		if(currGame != null) {
			throw new Exception("GameAlreadyProgressing");
		}
		
		if(schedule.size() == 0) {
			throw new Exception("NoGameScheduled");
		}
		
		restock();
		currGame = schedule.get(0);
		schedule.remove(0);
	}
	
	public void endGame() throws Exception{
		if(currGame == null) throw new Exception("NoGameScheduled");
		if(currGame.getHomeScore() == currGame.getAwayScore()) {
			throw new Exception("GameTied");
		}
		
		if(currGame.getHomeScore() > currGame.getAwayScore()) {
			team.addWin();
		}
		else {
			team.addLoss();
		}
		
		calculateProfit();
		
		team.addTenure();
		for(Store store : stores) {
			store.addTenure();
		}
		
		currGame = null;
	}
	
	public void incrementHome() throws Exception{
		if(currGame==null) throw new Exception("NoGameScheduled");
		
		currGame.setHomeScore(currGame.getHomeScore()+1);
	}
	
	public void incrementAway() throws Exception{
		if(currGame==null) throw new Exception("NoGameScheduled");
		
		currGame.setAwayScore(currGame.getAwayScore()+1);
	}
	
	public void decrementHome() throws Exception{
		if(currGame==null) throw new Exception("NoGameScheduled");
		if(currGame.getHomeScore() == 0) return;
		
		currGame.setHomeScore(currGame.getHomeScore()-1);
	}
	
	public void decrementAway() throws Exception{
		if(currGame==null) throw new Exception("NoGameScheduled");
		if(currGame.getAwayScore() == 0) return;
		
		currGame.setAwayScore(currGame.getAwayScore()-1);
	}
	
public static void saveData(Club club){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(club);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Club loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Club club=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			club = (Club) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return club;
	}
	
	public Team findTeam(String name) {
		for(int teamI = 0; teamI < opponents.size(); teamI++) {
			if(opponents.get(teamI).getTeamName().equals(name)) {
				return opponents.get(teamI);
			}
		}
		
		return null;
	}
}
