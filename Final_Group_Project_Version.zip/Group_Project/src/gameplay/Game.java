package gameplay;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import humans.Spectator;

public class Game implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3309399642129839202L;
	int schedule;
	Team awayTeam;
	int homeScore;
	int awayScore;
	ArrayList<Spectator> attendance;
	
	public Game() {
		schedule = -1;
		awayTeam = null;
		homeScore = 0;
		awayScore = 0;
		attendance = new ArrayList<Spectator>();
	}
	
	public Game(int schedule, Team awayTeam) {
		this.schedule = schedule;
		this.awayTeam = awayTeam;
		homeScore = 0;
		awayScore = 0;
		attendance = new ArrayList<Spectator>();
	}
	
	public int getSchedule() {
		return schedule;
	}

	public void setSchedule(int schedule) {
		this.schedule = schedule;
	}

	public Team getAwayTeam() {
		return awayTeam;
	}

	public void setAwayTeam(Team awayTeam) {
		this.awayTeam = awayTeam;
	}

	public int getHomeScore() {
		return homeScore;
	}

	public void setHomeScore(int homeScore) {
		this.homeScore = homeScore;
	}

	public int getAwayScore() {
		return awayScore;
	}

	public void setAwayScore(int awayScore) {
		this.awayScore = awayScore;
	}

	public ArrayList<Spectator> getAttendance() {
		return attendance;
	}

	public void setAttendance(ArrayList<Spectator> attendance) {
		this.attendance = attendance;
	}
	
public static void saveData(Game game){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(game);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Game loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Game game=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			game = (Game) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return game;
	}
}
