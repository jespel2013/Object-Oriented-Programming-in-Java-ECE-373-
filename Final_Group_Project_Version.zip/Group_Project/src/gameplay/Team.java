package gameplay;

import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

//import com.sun.xml.internal.ws.util.StringUtils;

import humans.GeneralManager;
import humans.Player;
import humans.ClubMember;

public class Team implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 9111510450785026527L;
	private String teamName;
	private GeneralManager generalManager;
	private ArrayList<Player> roster;
	private int winRecord;
	private int lossRecord;
	
	public Team() {
		teamName = "";
		generalManager = new GeneralManager();
		generalManager.setTeam(this);
		roster = new ArrayList<Player>();
		winRecord = 0;
		lossRecord = 0;
	}
	
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	
	public String getTeamName() {
		return teamName;
	}
	
	public void setGeneralManager(GeneralManager generalManager) {
		this.generalManager = generalManager;
	}
	
	public GeneralManager getGeneralManager() {
		return generalManager;
	}
	
	public ArrayList<Player> getRoster() {
		return roster;
	}

	public void setRoster(ArrayList<Player> roster) {
		this.roster = roster;
	}

	public int getWinRecord() {
		return winRecord;
	}

	public void setWinRecord(int winRecord) {
		this.winRecord = winRecord;
	}

	public int getLossRecord() {
		return lossRecord;
	}

	public void setLossRecord(int lossRecord) {
		this.lossRecord = lossRecord;
	}

	public void addWin() {
		winRecord++;
		generalManager.addWin();
	}
	
	public void addLoss() {
		lossRecord++;
		generalManager.addLoss();
	}
	
	public boolean checkConflictJersey(ClubMember aMember) {
		for(int i = 0; i < roster.size(); i++) {
			if(roster.get(i).getJerseyNum() == aMember.getJerseyNum()) {
				return true;
			}
		}
		
		return false;
	}
	
	public double calculateCosts() {
		double money = 0;
		money += generalManager.getPaycheck();
		
		for(int i = 0; i < roster.size(); i++) {
			money += roster.get(i).getPaycheck();
		}
		
		return money;
	}
	
	public void addTenure() {
		generalManager.setTenure(generalManager.getTenure() + 1);
		
		for(Player player : roster) {
			player.setTenure(player.getTenure() + 1);
		}
	}
	
	public String printRoster() {
		String str = "";
		
		for(Player p: roster) {
			str += p.getName() + " (" + p.getJerseyNum() + ") is a";
			if(p.getPosition() == 1) {
				str += " Pitcher";
			}
			else if(p.getPosition() == 2) {
				str += " Catcher";
			}
			else if(p.getPosition() == 3) {
				str += " First Baseman";
			}
			else if(p.getPosition() == 4) {
				str += " Second Baseman";
			}
			else if(p.getPosition() == 5) {
				str += " Third Baseman";
			}
			else if(p.getPosition() == 6) {
				str += " Shortstop";
			}
			else if(p.getPosition() == 7) {
				str += " Left Fielder";
			}
			else if(p.getPosition() == 8) {
				str += " Center Fielder";
			}
			else if(p.getPosition() == 9) {
				str += " RightFielder";
			}
			
			str += "\n";
		}
		return str.trim();
		
		
	}
	
	public Player findPlayer(String name) {
		
		for(int playerI = 0; playerI < roster.size(); playerI++) {
			if(roster.get(playerI).getName().equals(name)) {
				return roster.get(playerI);
			}
		}
		
		return null;
	}
	
public static void saveData(Team team){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(team);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Team loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Team team=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			team = (Team) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return team;
	}
}
