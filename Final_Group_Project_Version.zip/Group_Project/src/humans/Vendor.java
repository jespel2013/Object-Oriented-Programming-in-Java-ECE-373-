package humans;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import locations.Store;

public class Vendor extends Employee implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4395063126864214744L;
	private double wage;
	private Store assignedStore;
	
	//constructor
	public Vendor() {
		super();
		wage = 11.0;
		assignedStore = null;
	}
	//setters and getters
	public void setWage(double rate) {
		wage = rate;
	}
	public void setStore(Store aStore) {
		assignedStore = aStore;
	}
	public double getWage() {
		return wage;
	}
	public Store getStore() {
		return assignedStore;
	}
	//other methods
	public double getPaycheck() {
		return 5.0*wage;
	}


	public void giveRaise() {
		wage = 11.0 + (double)(super.getTenure()*.005);
		
	}
	
public static void saveData(Vendor vendor){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(vendor);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Vendor loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Vendor vendor=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			vendor = (Vendor) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return vendor;
	}
	
}
