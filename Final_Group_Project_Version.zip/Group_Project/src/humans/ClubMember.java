package humans;

import java.io.Serializable;

public abstract class ClubMember extends Employee implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -276021300227622101L;
	private int jerseyNum;
	private double salary;
	
	//constructor
	public ClubMember() {
		jerseyNum = -1;
		salary = 0.0;
	}
	
	//setters and getters
	public int getJerseyNum() {
		return jerseyNum;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double amount) {
		salary = amount;
	}
	public void setNumber(int number) {
		jerseyNum = number;
	}
	//FIXME BELOW
	public double getPaycheck() {
		return this.getSalary()/16.0; //pergame
	}
	
	public abstract void giveRaise();
	
	
}
