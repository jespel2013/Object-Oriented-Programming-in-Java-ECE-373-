package humans;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import locations.Item;
import locations.Store;
import locations.Ticket;
import locations.Ticketbooth;

public class Spectator extends Person implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8612370378405056458L;
	Ticket ticket;
	ArrayList<Item> itemsBought;
	
	public Spectator() {
		super();
		ticket = null;
		itemsBought = new ArrayList<Item>();
	}
	
	public Spectator(String name) {
		super(name);
		ticket = null;
		itemsBought = new ArrayList<Item>();
	}
	
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	
	public Ticket getTicket() {
		return ticket;
	}
	
	public void setItemsBought(ArrayList<Item> itemsBought) {
		this.itemsBought = itemsBought;
	}
	
	public ArrayList<Item> getItemsBought() {
		return itemsBought;
	}
	
	public void addItemBought(Item anItem) {
		for(Item item : itemsBought) {
			if (item.getName() == anItem.getName()) {
				item.setQuantity(item.getQuantity() + anItem.getQuantity());
				return;
			}
		}
		
		itemsBought.add(anItem);
	}
	
	public void buyItem(Item item, Store store) throws Exception {
		try {
			store.buyItem(item, this);
		}
		catch(Exception e) {
			throw e;
		}
	}
	
	public void buyTicket(Ticket t, Ticketbooth ticketbooth) throws Exception{
		try {
			ticketbooth.buyItem(t, this);
		}
		catch(Exception e) {
			throw e;
		}
	}
	
	public void showTickets(Ticketbooth ticketbooth) throws Exception {
		try {
			ticketbooth.showTickets();
		}
		catch(Exception e) {
			throw e;
		}
	}
	
public static void saveData(Person person){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(person);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Person loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Person person=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			person = (Person) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return person;
	}
}
