package humans;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Player extends ClubMember implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3206491566066405781L;
	private int position;
	
	
	//constructor 
	public Player() {
		super();
		position = 0;
	}
	
	//setters getters
	//this setter will return false if the postion is invalid
	public boolean setPosition(int pos) {
		if(pos < 10 && pos > 0) {
			position = pos;
			return true;
		}
		else {
			return false;
		}
	}
	
	public int getPosition() {
		return position;
	}
	
	public void giveRaise() {
		this.setSalary((double)(this.getSalary() * this.getTenure() * 0.01));
	}
	
public static void saveData(Player player){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(player);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Player loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Player player=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			player = (Player) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return player;
	}
}
