package humans;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import gameplay.Team;

public class GeneralManager extends ClubMember implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3241119837451631485L;
	private int totalWins;
	private int totalLosses;
	private int fanReputation;
	private Team team;
	
	public GeneralManager() {
		super();
		this.setNumber(0);
		totalWins = 0;
		totalLosses = 0;
		fanReputation = 50;
		team = null;
	}
	
	//getters and setters 
	public int getWins() {
		return totalWins;
	}
	public int getLosses() {
		return totalLosses;
	}
	public int getFanRep() {
		return fanReputation;
	}
	public Team getTeam() {
		return team;
	}
	
	public void setTeam(Team aTeam) {
		team = aTeam;
	}
	public void addWin() {
		totalWins++;
		fanReputation += 5;
	}
	public void addLoss() {
		totalLosses++;
		fanReputation -= 5;
	}
	
	//other methods
	public void addPlayer(Player aPlayer) throws Exception{
		for(Player p: team.getRoster()){
			if(aPlayer.getName().equals(p.getName()) && aPlayer.getPosition() == p.getPosition()
					&& aPlayer.getJerseyNum() == p.getJerseyNum()) {
				
			throw new Exception("MemberAlreadyOnTeam");
			}
		}
		
		if(aPlayer.getJerseyNum() < 0) {
			throw new Exception("JerseyNumberMustBePositive");
		}
		
		if(aPlayer.getJerseyNum() >= 100) {
			throw new Exception("JerseyNumberTooBig");
		}
		
		if(team.checkConflictJersey(aPlayer) || aPlayer.getJerseyNum() == this.getJerseyNum()) {
			throw new Exception("JerseyNumberTaken");
		}
		team.getRoster().add(aPlayer);
	}
	
	public void dropPlayer(Player aPlayer) throws Exception{
		boolean found = false;
		for(Player p: team.getRoster()) {
			if(aPlayer.getName().equals(p.getName()) && aPlayer.getPosition() == p.getPosition() && 
					aPlayer.getJerseyNum() == p.getJerseyNum()) {
				team.getRoster().remove(p);
				found = true;
				break;
			}
		}
		if(found == false) {
			throw new Exception("Player does not exist!");
		}
	}
	
	public void tradePlayer(Player newPlayer, Player oldPlayer) throws Exception {
		try {
			this.addPlayer(newPlayer);
		}
		catch(Exception e) {
			throw e;
		}
		
		this.dropPlayer(oldPlayer);
	}

	public void giveRaise() {
		if(totalWins >= totalLosses) {
			this.setSalary((double)(this.getSalary() * this.getTenure() * 0.01));
		}
		
	}
	
public static void saveData(GeneralManager generalManager){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(generalManager);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static GeneralManager loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		GeneralManager generalManager=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			generalManager = (GeneralManager) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return generalManager;
	}
}
