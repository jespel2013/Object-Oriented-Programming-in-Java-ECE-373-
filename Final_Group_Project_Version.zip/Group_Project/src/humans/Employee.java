package humans;

import java.io.Serializable;

public abstract class Employee extends Person implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -499671548522099336L;
	private int tenure;
	
	public Employee() {
		super();
		tenure = 0;
	}
	
	//setters and getters
	public void setTenure(int numGames){
		tenure = numGames;
	}
	
	public int getTenure() {
		return tenure;
	}
	
	public abstract double getPaycheck();
	public abstract void giveRaise();
}
