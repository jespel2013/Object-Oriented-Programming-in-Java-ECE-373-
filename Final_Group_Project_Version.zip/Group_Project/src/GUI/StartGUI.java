package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import gameplay.Club;

public class StartGUI extends JFrame{
	
	JLabel ticketboothimg;
	
	JButton start;
	Club club;
	
	public StartGUI(Club aClub) {
		
		super("Press Menu to Go to the Main Menu");
		club = aClub;
		
		ticketboothimg = new JLabel();
		ticketboothimg.setIcon(new ImageIcon("images/ticketbooth.jpg"));
		
		start = new JButton("Menu");
		start.addActionListener(new ButtonListener());
		
		

		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		//build
		FlowLayout layout = new FlowLayout();
		setLayout(layout);
		add(ticketboothimg);
		add(start);
		this.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		
		
		pack();
		setVisible(true);
	}
	
	private class ButtonListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			ClubGUI clubGUI = new ClubGUI("Club Window", club);
			setVisible(false);
			
		}
		
	}

}
