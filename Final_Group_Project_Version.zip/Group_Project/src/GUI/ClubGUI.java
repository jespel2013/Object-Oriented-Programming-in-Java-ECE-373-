package GUI;

import java.awt.*;
import java.awt.*;
import java.awt.event.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.*;

import gameplay.Club;
import gameplay.Game;
import gameplay.Team;
import locations.Ticket;
import locations.Ticketbooth;

public class ClubGUI extends JFrame{
	private Club club;
	Ticketbooth ticketbooth;
	
	private JMenuBar menuBar;		//the horizontal container
	private JMenu fileMenu;
	private JMenu gameMenu;
	private JMenu opponentMenu;	
	private JMenu gmMenu;
	private JMenu spectatorMenu;
	private JMenu viewMenu;
	
	
	
	//spectator view submenu
	private JMenuItem viewSeatingMap;
	private JMenuItem viewSoldTickets;
	private JMenuItem viewAvailableTickets;
	private JMenuItem buyTicket;
	private JMenuItem sellConcession;
	private JMenuItem sellTeamStore;
	
	// File submenus
    private JMenuItem fileSave;
    private JMenuItem fileLoad;
    private JMenuItem fileExit;

    // Student submenus
    private JMenuItem gameNew;
    private JMenuItem gameStart;
    private JMenuItem gameEnd;
    private JMenuItem gamePrint;
    
    // Opponent submenus
    private JMenuItem opponentAdd;
    private JMenuItem opponentPrint;
    
    //GM sub menu
    private JMenuItem addPlayer;
    private JMenuItem dropPlayer;
    private JMenuItem printCurrentRoster;
    
    //Game Panel
    private JPanel gamePanel;
    private JTextArea gameInfo;
    
    private JPanel homeButtons;
    private JPanel awayButtons;
    private JButton homeIncButton;
    private JButton homeDecButton;
    private JButton awayIncButton;
    private JButton awayDecButton;
    
    //Other frames
    AddPlayerFrame addPlayerFrame;
    DropPlayerFrame dropPlayerFrame;
    PrintRosterFrame printRosterFrame;
    //PrintRosterFrame printRosterFrame;
    
 	
 	public ClubGUI(String windowTitle, Club club) {
 		super(windowTitle);
 		this.club = club;
 		this.ticketbooth = (Ticketbooth)club.getStores().get(0);
 		
 		setSize(300, 100);
 		setLayout(new GridLayout(2,1));
		
		add(new JLabel("<HTML><center>Welcome to " + club.getStadium() + "." +
				"<BR>Choose an action from the above menus.</center></HTML>"), BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		buildGUI();	
		pack();
		setVisible(true);
 	}
 	
 	public void buildGUI() {
 		
 		menuBar = new JMenuBar();
     	
		// File Menu
		
		fileMenu = new JMenu("File");
		fileSave = new JMenuItem("Save");
		fileLoad = new JMenuItem("Load");
		fileExit = new JMenuItem("Exit");
		
		fileSave.addActionListener(new MenuListener());
		fileLoad.addActionListener(new MenuListener());
		fileExit.addActionListener(new MenuListener());
		
		fileMenu.add(fileSave);
		fileMenu.add(fileLoad);
		fileMenu.add(fileExit);
		
		gameMenu = new JMenu("Game");
		gameNew = new JMenuItem("New Game");
		gameStart = new JMenuItem("Start Game");
		gameEnd = new JMenuItem("End Game");
		gamePrint = new JMenuItem("Print Schedule");
		
		gameNew.addActionListener(new MenuListener());
		gameStart.addActionListener(new MenuListener());
		gameEnd.addActionListener(new MenuListener());
		gamePrint.addActionListener(new MenuListener());
		
		gameMenu.add(gameNew);
		gameMenu.add(gameStart);
		gameMenu.add(gameEnd);
		gameMenu.add(gamePrint);
		
		opponentMenu = new JMenu("Opponents");
		opponentAdd = new JMenuItem("Add Opponent");
		opponentPrint = new JMenuItem("Print Opponents");
		
		opponentAdd.addActionListener(new MenuListener());
		opponentPrint.addActionListener(new MenuListener());
		
		opponentMenu.add(opponentAdd);
		opponentMenu.add(opponentPrint);
		
		//gmMenu addPlayer
		gmMenu = new JMenu("General Manager");
		addPlayer = new JMenuItem("Add Player");
		addPlayer.addActionListener(new MenuListener());
		gmMenu.add(addPlayer);
		//dropplayer
		dropPlayer = new JMenuItem("Drop Player");
		dropPlayer.addActionListener(new MenuListener());
		gmMenu.add(dropPlayer);
		//print roster
		printCurrentRoster = new JMenuItem("Print Current Roster");
		printCurrentRoster.addActionListener(new MenuListener());
		gmMenu.add(printCurrentRoster);
		
		//spectator menu
		spectatorMenu = new JMenu("Spectator");
		viewMenu = new JMenu("View");
		viewSeatingMap = new JMenuItem("View Seating Map");
		viewSoldTickets = new JMenuItem("View Sold Tickets");
		viewAvailableTickets = new JMenuItem("View Available Tickets");
		buyTicket = new JMenuItem("Sell Ticket");
		sellConcession = new JMenuItem("Sell Concessions");
		sellTeamStore = new JMenuItem("Sell Team Store");
		
		viewSeatingMap.addActionListener(new MenuListener());
		viewSoldTickets.addActionListener(new MenuListener());
		viewAvailableTickets.addActionListener(new MenuListener());
		buyTicket.addActionListener(new MenuListener());
		sellConcession.addActionListener(new MenuListener());
		sellTeamStore.addActionListener(new MenuListener());
		
		
		viewMenu.add(viewSeatingMap);
		viewMenu.add(viewSoldTickets);
		viewMenu.add(viewAvailableTickets);
		
		
		spectatorMenu.add(viewMenu);
		spectatorMenu.add(buyTicket);
		spectatorMenu.add(sellConcession);
		spectatorMenu.add(sellTeamStore);
		
		
		
		menuBar.add(fileMenu);
		menuBar.add(gameMenu);
		menuBar.add(opponentMenu);
		menuBar.add(gmMenu);
		menuBar.add(spectatorMenu);
		
		setJMenuBar(menuBar);
		
		
		homeButtons = new JPanel(new GridLayout(2,1));
		homeIncButton = new JButton("Home +1");
		homeDecButton = new JButton("Home -1");
		awayButtons = new JPanel(new GridLayout(2,1));
		awayIncButton = new JButton("Away +1");
		awayDecButton = new JButton("Away -1");
		
		homeIncButton.addActionListener(new ButtonListener());
		homeDecButton.addActionListener(new ButtonListener());
		awayIncButton.addActionListener(new ButtonListener());
		awayDecButton.addActionListener(new ButtonListener());
		
		homeButtons.add(homeIncButton);
		homeButtons.add(homeDecButton);
		awayButtons.add(awayIncButton);
		awayButtons.add(awayDecButton);
		
		gameInfo = new JTextArea();
		drawGameInfo();
		
		gamePanel = new JPanel(new GridLayout(1,3));
		gamePanel.add(homeButtons);
		gamePanel.add(gameInfo);
		gamePanel.add(awayButtons);
		
		add(gamePanel);
 	}
 	
 	private class MenuListener implements ActionListener {
 		public void actionPerformed(ActionEvent e)
 		{
 			JMenuItem source = (JMenuItem)(e.getSource());
 			if(source.equals(fileSave)) {
				handleFileSave();
			}
			else if(source.equals(fileLoad)) {
				handleFileLoad();
			}
			else if(source.equals(fileExit)) {
				System.exit(0);
			}
			else if(source.equals(gameNew)) {
				handleGameNew();
			}
			else if(source.equals(gameStart)) {
				handleGameStart();
			}
			else if(source.equals(gameEnd)) {
				handleGameEnd();
			}
			else if(source.equals(gamePrint)) {
				handleGamePrint();
			}
			else if(source.equals(opponentAdd)) {
				handleOpponentAdd();
			}
			else if(source.equals(opponentPrint)) {
				handleOpponentPrint();
			}
			else if (source.equals(addPlayer)) {
				handleAddPlayer();
			}
			else if(source.equals(dropPlayer)) {
				handleDropPlayer();
			}
			else if(source.equals(printCurrentRoster)) {
				handlePrintRoster();
			}
			else if (source.equals(viewAvailableTickets)) {
				handleViewAvailableTickets();
			}
			else if (source.equals(viewSoldTickets)) {
				handleViewSoldTickets();
			}
			else if (source.equals(viewSeatingMap)) {
				handleViewSeatingMap();
			}
			else if (source.equals(buyTicket)) {
				handleBuyTicket();
			}
			else if(source.equals(sellConcession)) {
				handleSellConcession();
			}
			else if(source.equals(sellTeamStore)); {
				handleSellTeamStore();
			}
 		}
 		
 		private void handleFileSave() {
 			Club.saveData(club);
 			JOptionPane.showMessageDialog(null, "File Successfully Saved");
 			
 		}
 		
 		private void handleFileLoad() {
 			club = Club.loadData();
 			JOptionPane.showMessageDialog(null, "File Successfully Loaded");
 		}
 		
 		private void handleGameNew() {
 			AddNewGameWindow myWindow = new AddNewGameWindow();
 		}
 		
 		private void handleAddPlayer() {
 			addPlayerFrame = new AddPlayerFrame(club);
 		}
 		
 		private void handleDropPlayer() {
 			dropPlayerFrame = new DropPlayerFrame(club);
 		}
 		
 		private void handlePrintRoster() {
 			printRosterFrame = new PrintRosterFrame(club);
 		}
 		private void handleViewSoldTickets() {
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			PrintStream pstream = new PrintStream(stream);
			PrintStream stdout = System.out;
			System.setOut(pstream);
			
			for(Ticket t : ticketbooth.getSoldTickets()) {
				ticketbooth.printTicketInformation(t);
			}
			
			// Create a text pane
			JEditorPane textPane = new JEditorPane();
			textPane.setMargin(new Insets(0,20,0,0));
			textPane.setEditable(true);
			
			// Populate the text pane with the stream contents
			textPane.setText(stream.toString());
			textPane.setCaretPosition(0);
			
			// put the text pane in a scroll pane
			JScrollPane scrollPane = new JScrollPane(textPane);
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setPreferredSize(new Dimension(600, 400));
			
			// Put the scroll pane in a JFrame and show			
			JFrame frame = new JFrame("Sold Tickets");
			frame.add(scrollPane);
			frame.setSize(600, 800);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
			
			System.setOut(stdout);
		}
 		
 		private void handleViewAvailableTickets() {
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			PrintStream pstream = new PrintStream(stream);
			PrintStream stdout = System.out;
			System.setOut(pstream);
			
			for(Ticket t : ticketbooth.getAvailableTickets()) {
				ticketbooth.printTicketInformation(t);
			}
			
			// Create a text pane
			JEditorPane textPane = new JEditorPane();
			textPane.setMargin(new Insets(0,20,0,0));
			textPane.setEditable(true);
			
			// Populate the text pane with the stream contents
			textPane.setText(stream.toString());
			textPane.setCaretPosition(0);
			
			// put the text pane in a scroll pane
			JScrollPane scrollPane = new JScrollPane(textPane);
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setPreferredSize(new Dimension(600, 400));
			
			// Put the scroll pane in a JFrame and show			
			JFrame frame = new JFrame("Available Tickets");
			frame.add(scrollPane);
			frame.setSize(600, 800);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
			
			System.setOut(stdout);
		}
 		
 		private void handleBuyTicket() {
 			
 			if(club.getCurrGame() == null) {
 				JOptionPane.showMessageDialog(null,  "Error: no game started.", "Error", JOptionPane.ERROR_MESSAGE);
 				return;
 			}
 			
			JTextField section = new JTextField(10);
			JTextField row = new JTextField(10);
			JTextField number = new JTextField(10);
			
			JPanel panel = new JPanel();
			panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			
			panel.add(new JLabel("Section:"));
			panel.add(section);
			
			panel.add(new JLabel("Row:"));
			panel.add(row);
			
			panel.add(new JLabel("Number:"));
			panel.add(number);
			
			int result = JOptionPane.showConfirmDialog(null, panel, "Sell Ticket", JOptionPane.OK_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION) {
			int section_i = Integer.parseInt((section.getText()));
			char row_c = row.getText().charAt(0);
			int number_i = Integer.parseInt(number.getText());
			
			Ticket soldTicket = ticketbooth.sellTicket(new Ticket(section_i, row_c, number_i, (section_i/100)-1));
			
			if (soldTicket == null) {
				createMessageWindow("Error", "The entered ticket is not available."); 
			}
			else {
				createMessageWindow("Success", "Ticket has been sold.");
			}
			}
		}
 		
 		private void handleSellConcession() {
 			SellNewConcessionWindow myWindow = new SellNewConcessionWindow("Concessions Stand", club);
 		}
 		
 		private void handleSellTeamStore() {
 			SellNewTeamStoreWindow myWindow = new SellNewTeamStoreWindow("Team Store", club);
 		}
		
		private void createMessageWindow(String title, String message) {
			JOptionPane.showMessageDialog(null, 
					message,
					title, 
					JOptionPane.PLAIN_MESSAGE);
			return;
		}
		
		private void handleViewSeatingMap() {
			//JPanel panel = new JPanel();
			
			JFrame frame = new JFrame("Seating Map");
			frame.setSize(1200, 600);
			
			JLabel seatingMap = new JLabel();
			ImageIcon imageIcon = new ImageIcon("images/seating.jpg"); // load the image to a imageIcon
			Image image = imageIcon.getImage(); // transform it 
			Image newimg = image.getScaledInstance(1200, 600,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
			imageIcon = new ImageIcon(newimg);  // transform it back
			seatingMap.setIcon(imageIcon);
			
			frame.add(seatingMap);
			
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setVisible(true);
		}
 		
 		private void handleGameStart() {
 			try {
 				club.startGame();
 				JOptionPane.showMessageDialog(null,  "Game started against Team " + club.getCurrGame().getAwayTeam().getTeamName()+".",
 												"Success", JOptionPane.PLAIN_MESSAGE);
 				
 				drawGameInfo();
 				pack();
 			}
 			catch(Exception e) {
 				if(e.getMessage().equals("GameAlreadyProgressing")) {
 					JOptionPane.showMessageDialog(null,  "A game is already progressing.",
 							"Error", JOptionPane.ERROR_MESSAGE);
 				}
 				else if(e.getMessage().equals("NoGameScheduled")) {
 					JOptionPane.showMessageDialog(null,  "No games are scheduled.",
 							"Error", JOptionPane.ERROR_MESSAGE);
 				}
 			}
 		}
 		
 		private void handleGameEnd() {
 			try {
 				club.endGame();
 				JOptionPane.showMessageDialog(null, String.format("Game Ended. \nTotal Club Profit: $%.2f.", club.getProfit()),
 						"Success", JOptionPane.PLAIN_MESSAGE);
 				gameInfo.removeAll();
				gameInfo.setText("No Game Playing");
				pack();
			}
			catch(Exception e) {
				if(e.getMessage().equals("GameTied")) {
					JOptionPane.showMessageDialog(null,  "The game is currently tied.",
							"Error", JOptionPane.ERROR_MESSAGE);
				}
				else if(e.getMessage().equals("NoGameScheduled")) {
					JOptionPane.showMessageDialog(null,  "No game is scheduled.",
							"Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
 		
 		private void handleGamePrint() {
			ArrayList<Game> sched = club.getSchedule();
			JTextArea outText = new JTextArea("Opponent\t\tDate\tTime\n");
			for(int gameI = 0; gameI < sched.size(); gameI++) {
				Game currGame = sched.get(gameI);
				outText.setText(outText.getText() + currGame.getAwayTeam().getTeamName() +"\t\t"+(currGame.getSchedule()/100) + "\t"+(currGame.getSchedule()%100)+"\n");
			}
	
			
			JOptionPane.showMessageDialog(null,  outText, "Game Schedule", JOptionPane.PLAIN_MESSAGE);
		}
		
		private void handleOpponentAdd() {
			AddNewOpponentWindow myWindow = new AddNewOpponentWindow();
		}
		
		private void handleOpponentPrint() {
			ArrayList<Team> opponents = club.getOpponents();
			JTextArea outText = new JTextArea("Opponents:\n");
			for(int teamI = 0; teamI < opponents.size(); teamI++) {
				outText.setText(outText.getText() + opponents.get(teamI).getTeamName()+"\n");
			}
			JOptionPane.showMessageDialog(null, outText, "Opponent List", JOptionPane.PLAIN_MESSAGE);
		}
 	}
 	
 	

	
	public class AddNewGameWindow {
		private JPanel fieldPanel;
		private JTextField gameDay;
		private JTextField gameTime;
		private JTextField gameOpponent;
		
		private Team targetOpponent;
		
		public AddNewGameWindow() {
			gameDay = new JTextField(2);
			gameTime = new JTextField(2);
			gameOpponent = new JTextField(20);
			
			fieldPanel = new JPanel(new GridLayout(3,2));
			fieldPanel.add(new JLabel("Game Day (1-31):"));
			fieldPanel.add(gameDay);
			fieldPanel.add(new JLabel("Game Time (0-23):"));
			fieldPanel.add(gameTime);
			fieldPanel.add(new JLabel("Opponent Name:"));
			fieldPanel.add(gameOpponent);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Add Game", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetOpponent = club.findTeam(gameOpponent.getText().trim());
				int targetSched;
				try {
					targetSched = (Integer.parseInt(gameDay.getText()) * 100) + Integer.parseInt(gameTime.getText());
				}
				catch(Exception e) {
					JOptionPane.showMessageDialog(null,  "Error: Game Day or Time is not an integer", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				if(targetOpponent == null) {
					JOptionPane.showMessageDialog(null,  "Team " + gameOpponent.getText() + " doesn't exist.",
													"Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				Game newGame = new Game(targetSched, targetOpponent);
				try {
					club.scheduleGame(newGame);
					JOptionPane.showMessageDialog(null,  "Success! Game added Day "+gameDay.getText()+" at Time "+gameTime.getText()+" against "+gameOpponent.getText(),
							"Success", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				catch(Exception e) {
					if(e.getMessage().equals("TeamNotFound")) {
						JOptionPane.showMessageDialog(null,  "Team " + targetOpponent.getTeamName() + " doesn't exist.",
								"Error", JOptionPane.ERROR_MESSAGE);
					}
					else if(e.getMessage().equals("InvalidDate")) {
						JOptionPane.showMessageDialog(null,  "Invalid Date Entered",
								"Error", JOptionPane.ERROR_MESSAGE);
					}
					else if(e.getMessage().equals("InvalidTime")) {
						JOptionPane.showMessageDialog(null,  "Invalid Time Entered",
								"Error", JOptionPane.ERROR_MESSAGE);
					}
					else if(e.getMessage().equals("GameAlreadyScheduled")) {
						JOptionPane.showMessageDialog(null,  "Game already scheduled that day.",
								"Error", JOptionPane.ERROR_MESSAGE);
					}
					return;
				}
			}
		}
	}
	
	public class AddNewOpponentWindow {
		private JPanel fieldPanel;
		private JTextField opponentName;
		
		private Team targetOpponent;
		
		public AddNewOpponentWindow() {
			opponentName = new JTextField(20);
			
			fieldPanel = new JPanel(new GridLayout(3,2));
			fieldPanel.add(new JLabel("Opponent Name:"));
			fieldPanel.add(opponentName);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Add Opponent", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetOpponent = club.findTeam(opponentName.getText().trim());
				
				if(targetOpponent != null) {
					JOptionPane.showMessageDialog(null,  "Team " + opponentName.getText() + " already exist.",
													"Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				Team newTeam = new Team();
				newTeam.setTeamName(opponentName.getText().trim());
				club.getOpponents().add(newTeam);
				JOptionPane.showMessageDialog(null,  "Success! Added opponent "+opponentName.getText()+".",
							"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
	
	private class ButtonListener implements ActionListener {
 		public void actionPerformed(ActionEvent e)
 		{
 			JButton source = (JButton)(e.getSource());
 			if(source.equals(homeIncButton)) {
 				handleHomeIncButton();
 			}
 			else if(source.equals(homeDecButton)) {
 				handleHomeDecButton();
 			}
 			else if(source.equals(awayIncButton)) {
 				handleAwayIncButton();
 			}
 			else if(source.equals(awayDecButton)) {
 				handleAwayDecButton();
 			}
 		}
 		
 		private void handleHomeIncButton() {
 			try {
 				club.incrementHome();
 				drawGameInfo();
 			}
 			catch(Exception e) {
 				if(e.getMessage().equals("NoGameScheduled")) {
 					JOptionPane.showMessageDialog(null,  "No Game is being played right now.",
							"Error", JOptionPane.ERROR_MESSAGE);
 				}
 			}
 		}
 		
 		private void handleHomeDecButton() {
 			try {
 				club.decrementHome();
 				drawGameInfo();
 			}
 			catch(Exception e) {
 				if(e.getMessage().equals("NoGameScheduled")) {
 					JOptionPane.showMessageDialog(null,  "No Game is being played right now.",
							"Error", JOptionPane.ERROR_MESSAGE);
 				}
 			}
 		}
 		
 		private void handleAwayIncButton() {
 			try {
 				club.incrementAway();
 				drawGameInfo();
 			}
 			catch(Exception e) {
 				if(e.getMessage().equals("NoGameScheduled")) {
 					JOptionPane.showMessageDialog(null,  "No Game is being played right now.",
							"Error", JOptionPane.ERROR_MESSAGE);
 				}
 			}
 		}
 		
 		private void handleAwayDecButton() {
 			try {
 				club.decrementAway();
 				drawGameInfo();
 			}
 			catch(Exception e) {
 				if(e.getMessage().equals("NoGameScheduled")) {
 					JOptionPane.showMessageDialog(null,  "No Game is being played right now.",
							"Error", JOptionPane.ERROR_MESSAGE);
 				}
 			}
 		}
	}
	
	public void drawGameInfo() {
		if(club.getCurrGame() == null) {
			gameInfo.setText("No Game Playing");
		}
		else {
			gameInfo.setText("Game Against Team "+club.getCurrGame().getAwayTeam().getTeamName()+"\n" +
						"Home Team\t\tAwayTeam\n"+
						club.getTeam().getTeamName()+"\t\t"+club.getCurrGame().getAwayTeam().getTeamName()+"\n"+
						club.getCurrGame().getHomeScore()+"\t\t"+club.getCurrGame().getAwayScore()	 );
		}
	}
}
