package GUI;

import java.awt.*;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import gameplay.Club;
import humans.Player;



public class AddPlayerFrame extends JFrame{
		// labels
		private JLabel playerName;
		private JLabel position;
		private JLabel salary;
		private JLabel number;
		// buttons
		private JButton ok;
		private JButton cancel;
		// text fields
		private JTextField nameField;
		private JTextField posField;
		private JTextField salField;
		private JTextField numField;

		// Club object
		private Club club;
		
		//constructors
		public AddPlayerFrame(Club theClub) {
			super("Add Player");
			club = theClub;
			
			buildGUI();

			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			pack();
			setVisible(true);
		}
		
		public AddPlayerFrame() {
			super("Add Player");
				club = new Club();
				
				buildGUI();

				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				pack();
				setVisible(true);
		}
		
		
		private void buildGUI() {
			setSize(350, 350);

			setLayout(new FlowLayout());

			JPanel p1 = new JPanel(); 
			JPanel p2 = new JPanel();
			JPanel p3 = new JPanel();

			p1.setLayout(new GridLayout(4, 2));
			p2.setLayout(new GridLayout(1, 2));
			p3.setLayout(new GridLayout(2,1));
			
			//borders
			p2.setBorder(new EmptyBorder(25, 50, 20, 50));
			p3.setBorder(new EmptyBorder(10, 10, 10, 10));


			

			// labels
			playerName = new JLabel("Name: ");
			position = new JLabel("Position (1-9): ");
			salary = new JLabel("Salary: ");
			number = new JLabel("Jersey Number: ");
			

			// fields
			nameField = new JTextField(15);
			posField = new JTextField(15);
			salField = new JTextField(15);
			numField = new JTextField(15);


			// Buttons
			ok = new JButton("OK");
			cancel = new JButton("Cancel");
			
			ok.addActionListener(new ButtonListener());
			cancel.addActionListener(new ButtonListener());

			p1.add(playerName);
			p1.add(nameField);
			
			p1.add(position);
			p1.add(posField);
			
			p1.add(salary);
			p1.add(salField);
		
			p1.add(number);
			p1.add(numField);

			p2.add(ok);
			p2.add(cancel);
			
			
			p3.add(p1);
			p3.add(p2);

			add(p3, BorderLayout.CENTER);
			
		}

		private class ButtonListener implements ActionListener {
			public void actionPerformed(ActionEvent e) // this is the method MenuListener must implement, as it comes from
														// the ActionListener interface.
			{
				JButton source = (JButton) (e.getSource());
				if (source.equals(ok)) {
					handleOk();
				} else if (source.equals(cancel)) {
					setVisible(false);
					dispose();
				}
			}

			public void handleOk() {
				String n = nameField.getText();
				int p = Integer.parseInt(posField.getText());
				double s = Double.parseDouble(salField.getText());
				int j = Integer.parseInt(numField.getText());
				
				Player player = new Player();
				
				player.setName(n);
				player.setPosition(p);
				player.setSalary(s);
				player.setNumber(j);
				
				try {
					club.getTeam().getGeneralManager().addPlayer(player);
					JOptionPane.showMessageDialog(null, "Player Successfully Added!");
				}
				catch (Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
				
				dispose();
			}
		}
}
