package GUI;

import java.awt.*;
import java.awt.*;
import java.awt.event.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.*;

import gameplay.Club;
import gameplay.Game;
import gameplay.Team;
import humans.Spectator;
import locations.Concessions;
import locations.Item;
import locations.Ticket;
import locations.Ticketbooth;

public class SellNewConcessionWindow extends JFrame{
	private Club club;
	Concessions concessions;
	
	private JMenuBar menuBar;		//the horizontal container
	private JMenu fileMenu;
	private JMenu itemMenu;
	
	// File submenus
    private JMenuItem fileSave;
    private JMenuItem fileLoad;
    private JMenuItem fileExit;
	
	//item submenu
	private JMenuItem itemAdd;
	private JMenuItem itemRemove;
	private JMenuItem itemChangeName;
	private JMenuItem itemChangeStock;
	private JMenuItem itemChangeBuyPrice;
	private JMenuItem itemChangeSellPrice;
	
    
    //Stock Panel
    private JPanel stockPanel;
    private JTextArea stockInfo;
    
    
    private JPanel transactionPanel;
    private JTextField itemInput;
    private JPanel buttonPanel;
    private JButton incButton;
    private JButton decButton;
    private JButton buyButton;
    private JLabel itemQuantity;
    private int quantity;
    
 	
 	public SellNewConcessionWindow(String windowTitle, Club club) {
 		super(windowTitle);
 		this.club = club;
 		this.concessions = (Concessions)club.getStores().get(2);
 		
 		setSize(300, 100);
 		setLayout(new GridLayout(5,1));
		
		add(new JLabel("<HTML><center>Welcome to " + club.getStadium() + " Concessions." +
				"<BR>Choose an action from the above menus or perform transaction below.</center></HTML>"), BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		buildGUI();	
		pack();
		setVisible(true);
 	}
 	
 	public void buildGUI() {
 		
 		menuBar = new JMenuBar();
     	
		// File Menu
		
		fileMenu = new JMenu("File");
		fileSave = new JMenuItem("Save");
		fileLoad = new JMenuItem("Load");
		fileExit = new JMenuItem("Exit");
		
		fileSave.addActionListener(new MenuListener());
		fileLoad.addActionListener(new MenuListener());
		fileExit.addActionListener(new MenuListener());
		
		fileMenu.add(fileSave);
		fileMenu.add(fileLoad);
		fileMenu.add(fileExit);
		
		itemMenu = new JMenu("Item");
		itemAdd = new JMenuItem("Add New Item");
		itemRemove = new JMenuItem("Remove Item");
		itemChangeName = new JMenuItem("Change Item Name");
		itemChangeStock = new JMenuItem("Change Max Stock");
		itemChangeBuyPrice = new JMenuItem("Change Item Buy Price");
		itemChangeSellPrice = new JMenuItem("Change Item Sell Price");

		
		itemAdd.addActionListener(new MenuListener());
		itemRemove.addActionListener(new MenuListener());
		itemChangeName.addActionListener(new MenuListener());
		itemChangeStock.addActionListener(new MenuListener());
		itemChangeBuyPrice.addActionListener(new MenuListener());
		itemChangeSellPrice.addActionListener(new MenuListener());
		
		itemMenu.add(itemAdd);
		itemMenu.add(itemRemove);
		itemMenu.add(itemChangeName);
		itemMenu.add(itemChangeStock);
		itemMenu.add(itemChangeBuyPrice);
		itemMenu.add(itemChangeSellPrice);
		
				
		menuBar.add(fileMenu);
		menuBar.add(itemMenu);
		
		setJMenuBar(menuBar);
		
		transactionPanel = new JPanel(new GridLayout(2,3));
		
		itemInput = new JTextField(10);
		
		buttonPanel = new JPanel(new GridLayout(2,1));
		incButton = new JButton("+1");
		decButton = new JButton("-1");
		buttonPanel.add(incButton);
		buttonPanel.add(decButton);
		
		buyButton = new JButton("Purhcase");
		
		incButton.addActionListener(new ButtonListener());
		decButton.addActionListener(new ButtonListener());
		buyButton.addActionListener(new ButtonListener());
		
		quantity = 0;
		itemQuantity = new JLabel("Quantity: 0");
		
		transactionPanel.add(new JLabel("Item:"));
		transactionPanel.add(itemInput);
		transactionPanel.add(new JLabel());
		transactionPanel.add(buttonPanel);
		transactionPanel.add(itemQuantity);
		transactionPanel.add(buyButton);
		
		add(new JLabel("Concessions Transaction:"));
		add(transactionPanel);
		//Stock Panel
	    stockPanel = new JPanel();
	    stockInfo = new JTextArea();
		
		drawStockInfo();
		
		stockPanel.add(stockInfo);
		
		add(new JLabel("Menu:"));
		add(stockPanel);
 	}
 	
 	private class MenuListener implements ActionListener {
 		public void actionPerformed(ActionEvent e)
 		{
 			JMenuItem source = (JMenuItem)(e.getSource());
 			if(source.equals(fileSave)) {
				handleFileSave();
			}
			else if(source.equals(fileLoad)) {
				handleFileLoad();
			}
			else if(source.equals(fileExit)) {
				System.exit(0);
			}
			else if(source.equals(itemAdd)) {
				handleItemAdd();
			}
			else if(source.equals(itemRemove)) {
				handleItemRemove();
			}
			else if(source.equals(itemChangeName)) {
				handleItemChangeName();
			}
			else if(source.equals(itemChangeStock)) {
				handleItemChangeStock();
			}
			else if(source.equals(itemChangeBuyPrice)) {
				handleItemChangeBuyPrice();
			}
			else if(source.equals(itemChangeSellPrice)) {
				handleItemChangeSellPrice();
			}
 		}
 		
 		private void handleFileSave() {
 			Club.saveData(club);
 			JOptionPane.showMessageDialog(null, "File Successfully Saved");
 			
 		}
 		
 		private void handleFileLoad() {
 			club = Club.loadData();
 			JOptionPane.showMessageDialog(null, "File Successfully Loaded");
 		}
 		
 		private void handleItemAdd() {
 			AddNewItemWindow myWindow = new AddNewItemWindow();
 		}
 		
 		private void handleItemRemove() {
 			RemoveItemWindow myWindow = new RemoveItemWindow();;
 		}
 		
 		private void handleItemChangeName() {
 			ChangeItemNameWindow myWindow= new ChangeItemNameWindow();
 		}
 		
 		private void handleItemChangeStock() {
 			ChangeItemStockWindow myWindow = new ChangeItemStockWindow();
 		}
 		private void handleItemChangeBuyPrice() {
			ChangeItemBuyPriceWindow myWindow = new ChangeItemBuyPriceWindow();
		}
 		private void handleItemChangeSellPrice() {
			ChangeItemSellPriceWindow myWindow = new ChangeItemSellPriceWindow();
		}
 	}
 	
 	

	
	public class AddNewItemWindow {
		private JPanel fieldPanel;
		private JTextField itemName;
		private JTextField itemMaxStock;
		private JTextField itemBuyPrice;
		private JTextField itemSellPrice;
		
		private Item targetItem;
		
		public AddNewItemWindow() {
			if(club.getCurrGame() != null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot add new item during game.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
			itemName = new JTextField(10);
			itemMaxStock = new JTextField(2);
			itemBuyPrice = new JTextField(5);
			itemSellPrice = new JTextField(5);
			
			fieldPanel = new JPanel(new GridLayout(4,2));
			fieldPanel.add(new JLabel("Item Name:"));
			fieldPanel.add(itemName);
			fieldPanel.add(new JLabel("Max Stock:"));
			fieldPanel.add(itemMaxStock);
			fieldPanel.add(new JLabel("Buy Price:"));
			fieldPanel.add(itemBuyPrice);
			fieldPanel.add(new JLabel("Sell Price:"));
			fieldPanel.add(itemSellPrice);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Add Item", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetItem = concessions.findItem(itemName.getText().trim());
				
				if(targetItem != null) {
					JOptionPane.showMessageDialog(null,  "Error: That item already exists.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				Item newItem = new Item();
				newItem.setName(itemName.getText().trim());
				newItem.setMaxStock(Integer.parseInt(itemMaxStock.getText().trim()));
				if(newItem.getMaxStock() < 0) {
					JOptionPane.showMessageDialog(null,  "Error: Max Stock must be >= 0", "Error", JOptionPane.ERROR_MESSAGE);
				}
				
				newItem.setBuyPrice(Float.parseFloat(itemBuyPrice.getText().trim()));
				if(newItem.getBuyPrice() < 0) {
					JOptionPane.showMessageDialog(null,  "Error: Buy Price must be >= 0", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				newItem.setSellPrice(Float.parseFloat(itemSellPrice.getText().trim()));
				if(newItem.getSellPrice() < 0) {
					JOptionPane.showMessageDialog(null,  "Error: Sell Price must be >= 0", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				concessions.addItem(newItem);
				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! Item \""+itemName.getText()+"\" added to Concessions.",
						"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
	
	public class RemoveItemWindow {
		private JPanel fieldPanel;
		private JTextField itemName;
		
		private Item targetItem;
		
		public RemoveItemWindow() {
			if(club.getCurrGame() != null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot remove item during game.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
			itemName = new JTextField(10);
			
			fieldPanel = new JPanel(new GridLayout(1,2));
			fieldPanel.add(new JLabel("Item Name:"));
			fieldPanel.add(itemName);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Remove Item", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetItem = concessions.findItem(itemName.getText().trim());
				
				if(targetItem == null) {
					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemName.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				concessions.getInventory().remove(targetItem);
				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! Item \""+itemName.getText()+"\" removed.",
						"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
	
	public class ChangeItemNameWindow {
		private JPanel fieldPanel;
		private JTextField itemName;
		private JTextField newItemName;
		
		private Item targetItem;
		
		public ChangeItemNameWindow() {
			if(club.getCurrGame() != null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot change items during game.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
			itemName = new JTextField(10);
			newItemName = new JTextField(10);
			
			fieldPanel = new JPanel(new GridLayout(2,2));
			fieldPanel.add(new JLabel("Item Name:"));
			fieldPanel.add(itemName);
			fieldPanel.add(new JLabel("New Item Name:"));
			fieldPanel.add(newItemName);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Change Item Name", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetItem = concessions.findItem(itemName.getText().trim());
				
				if(targetItem == null) {
					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemName.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				targetItem.setName(newItemName.getText().trim());
				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! Item \""+itemName.getText()+"\" changed to \""+newItemName.getText()+"\".",
						"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
	
	public class ChangeItemStockWindow {
		private JPanel fieldPanel;
		private JTextField itemName;
		private JTextField newStock;
		
		private Item targetItem;
		
		public ChangeItemStockWindow() {
			if(club.getCurrGame() != null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot change items during game.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
			itemName = new JTextField(10);
			newStock = new JTextField(2);
			
			fieldPanel = new JPanel(new GridLayout(2,2));
			fieldPanel.add(new JLabel("Item Name:"));
			fieldPanel.add(itemName);
			fieldPanel.add(new JLabel("New Max Stock:"));
			fieldPanel.add(newStock);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Change Item Max Stock", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetItem = concessions.findItem(itemName.getText().trim());
				
				if(targetItem == null) {
					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemName.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				int newMaxStock = Integer.parseInt(newStock.getText().trim());
				if(newMaxStock < 0) {
					JOptionPane.showMessageDialog(null,  "Error: Max stock must be >= 0.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				targetItem.setMaxStock(newMaxStock);
				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! Item \""+itemName.getText()+"\" changed to max stock "+newStock.getText()+".",
						"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
	
	public class ChangeItemBuyPriceWindow {
		private JPanel fieldPanel;
		private JTextField itemName;
		private JTextField newBuyPrice;
		
		private Item targetItem;
		
		public ChangeItemBuyPriceWindow() {
			if(club.getCurrGame() != null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot change items during game.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
			itemName = new JTextField(10);
			newBuyPrice = new JTextField(2);
			
			fieldPanel = new JPanel(new GridLayout(2,2));
			fieldPanel.add(new JLabel("Item Name:"));
			fieldPanel.add(itemName);
			fieldPanel.add(new JLabel("New Buy Price: $"));
			fieldPanel.add(newBuyPrice);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Change Item Buy Price", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetItem = concessions.findItem(itemName.getText().trim());
				
				if(targetItem == null) {
					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemName.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				float price = Float.parseFloat(newBuyPrice.getText().trim());
				if(price < 0) {
					JOptionPane.showMessageDialog(null,  "Error: Buy price must be >= 0.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				targetItem.setBuyPrice(price);
				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! Item \""+itemName.getText()+"\" changed to buy price $"+newBuyPrice.getText()+".",
						"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
		
		
	}
	
	public class ChangeItemSellPriceWindow {
		private JPanel fieldPanel;
		private JTextField itemName;
		private JTextField newSellPrice;
		
		private Item targetItem;
		
		public ChangeItemSellPriceWindow() {
			if(club.getCurrGame() != null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot change items during game.",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
			itemName = new JTextField(10);
			newSellPrice = new JTextField(2);
			
			fieldPanel = new JPanel(new GridLayout(2,2));
			fieldPanel.add(new JLabel("Item Name:"));
			fieldPanel.add(itemName);
			fieldPanel.add(new JLabel("New Sell Price: $"));
			fieldPanel.add(newSellPrice);
			
			int result = JOptionPane.showConfirmDialog(null,  fieldPanel, "Change Item Sell Price", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {
				targetItem = concessions.findItem(itemName.getText().trim());
				
				if(targetItem == null) {
					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemName.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				float price = Float.parseFloat(newSellPrice.getText().trim());
				if(price < 0) {
					JOptionPane.showMessageDialog(null,  "Error: Sell price must be >= 0.", "Error", JOptionPane.ERROR_MESSAGE);
					return;
				}
				
				targetItem.setSellPrice(price);
				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! Item \""+itemName.getText()+"\" changed to buy price $"+newSellPrice.getText()+".",
						"Success", JOptionPane.PLAIN_MESSAGE);
			}
		}
		
		
	}
	
	
	
	private class ButtonListener implements ActionListener {
 		public void actionPerformed(ActionEvent e)
 		{
 			JButton source = (JButton)(e.getSource());
 			if(source.equals(incButton)) {
 				handleIncButton();
 			}
 			else if(source.equals(decButton)) {
 				handleDecButton();
 			}
 			else if(source.equals(buyButton)) {
 				handleBuyButton();
 			}
 		}
 		
 		private void handleIncButton() {
 			quantity++;
 			itemQuantity.setText(String.format("Quantity: %d", quantity));
 			drawStockInfo();
 		}
 		
 		private void handleDecButton() {
 			if(quantity > 0) {
 				quantity--;
 			}
 			itemQuantity.setText(String.format("Quantity: %d", quantity));
 			drawStockInfo();
 		}
 		
 		private void handleBuyButton() {
 			Item targetItem;
 			
 			if(club.getCurrGame() == null) {
				JOptionPane.showMessageDialog(null,  "Error: Cannot sell items outside gametime.",
						"Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
 			
 			targetItem = concessions.findItem(itemInput.getText().trim());
 			
 			if(targetItem == null) {
				JOptionPane.showMessageDialog(null,  "Error: Item \""+itemInput.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
				return;
			}
 			
 			try {
 				Item toBuy = new Item();
 				toBuy.setName(targetItem.getName());
 				toBuy.setQuantity(quantity);
 				concessions.buyItem(toBuy, new Spectator());
 				drawStockInfo();
				JOptionPane.showMessageDialog(null,  "Success! "+String.format("%d", quantity) +" items of \""+targetItem.getName()+"\" sold.",
						"Success", JOptionPane.PLAIN_MESSAGE);
 			}
 			catch(Exception e) {
 				if(e.getMessage().equals("ItemOutOfStock")) {
 					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemInput.getText()+" is out of stock.", "Error", JOptionPane.ERROR_MESSAGE);
 					return;
 				}
 				
 				else if(e.getMessage().equals("ItemLowOnStock")) {
 					JOptionPane.showMessageDialog(null,  "Error: Only "+targetItem.getQuantity()+" of item \""+itemInput.getText()+" in stock.", "Error", JOptionPane.ERROR_MESSAGE);
 					return;
 				}
 				
 				else if(e.getMessage().equals("ItemNotInStock")) {
 					JOptionPane.showMessageDialog(null,  "Error: Item \""+itemInput.getText()+" cannot be found.", "Error", JOptionPane.ERROR_MESSAGE);
 					return;
 				}
 			}
 		}
	}
	
	public void drawStockInfo() {
		stockInfo.setText("Concessions:\n"+
				"Item\t\tStock\tPrice\n");
		
		for(int itemI = 0; itemI < concessions.getInventory().size(); itemI++) {
			Item currItem = concessions.getInventory().get(itemI);
			stockInfo.setText(stockInfo.getText()+currItem.getName()+"\t\t"+currItem.getQuantity()+"\t$"+String.format("%.2f",currItem.getSellPrice())+"\n");
		}
		pack();
	}
}
