package GUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


import gameplay.Club;
import humans.Player;

public class DropPlayerFrame extends JFrame{
	// labels
			private JLabel playerName;

			// buttons
			private JButton ok;
			private JButton cancel;
			// text fields
			private JTextField nameField;


			// Club object
			private Club club;
			
			//constructors
			public DropPlayerFrame(Club theClub) {
				super("Drop Player");
				club = theClub;
				
				buildGUI();

				setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				pack();
				setVisible(true);
			}
			
			public DropPlayerFrame() {
				super("Drop Player");
					club = new Club();
					
					buildGUI();

					setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					pack();
					setVisible(true);
			}
			
			
			private void buildGUI() {
				setSize(350, 350);

				setLayout(new FlowLayout());

				JPanel p1 = new JPanel(); 
				JPanel p2 = new JPanel();
				JPanel p3 = new JPanel();

				p1.setLayout(new GridLayout(4, 2));
				p2.setLayout(new GridLayout(1, 2));
				p3.setLayout(new GridLayout(2,1));
				
				//borders
				p2.setBorder(new EmptyBorder(25, 50, 20, 50));
				p3.setBorder(new EmptyBorder(10, 10, 10, 10));


				

				// labels
				playerName = new JLabel("Name: ");
				

				// fields
				nameField = new JTextField(15);


				// Buttons
				ok = new JButton("OK");
				cancel = new JButton("Cancel");
				
				ok.addActionListener(new ButtonListener());
				cancel.addActionListener(new ButtonListener());

				p1.add(playerName);
				p1.add(nameField);
				

				p2.add(ok);
				p2.add(cancel);
				
				
				p3.add(p1);
				p3.add(p2);

				add(p3, BorderLayout.CENTER);
				
			}

			private class ButtonListener implements ActionListener {
				public void actionPerformed(ActionEvent e) // this is the method MenuListener must implement, as it comes from
															// the ActionListener interface.
				{
					JButton source = (JButton) (e.getSource());
					if (source.equals(ok)) {
						handleOk();
					} else if (source.equals(cancel)) {
						setVisible(false);
						dispose();
					}
				}

				public void handleOk() {
					String n = nameField.getText();
					
					Player player;
					
					player = club.getTeam().findPlayer(n.trim());
					
					if(player == null) {
						JOptionPane.showMessageDialog(null, "Player not in roster.", "error", JOptionPane.ERROR_MESSAGE);
					}
					else {
					
						try {
							club.getTeam().getGeneralManager().dropPlayer(player);
							JOptionPane.showMessageDialog(null, "Player Successfully Dropped!");
						}
						catch (Exception e) {
							JOptionPane.showMessageDialog(null, e);
						}
					}
					
					dispose();
				}
			}
}
