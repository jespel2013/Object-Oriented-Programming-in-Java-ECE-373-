package GUI;

import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.io.*;

import locations.Ticket;
import locations.Ticketbooth;
import humans.Spectator;

public class TicketBoothGUI extends JFrame {
	private Ticketbooth ticketBooth;	
	private JMenuBar menuBar;
	private JMenu fileMenu;
	private JMenu viewMenu;
	private JMenuItem ticketsMenu;
	
	// File submenus
	private JMenuItem fileSave;
	private JMenuItem fileLoad;
	private JMenuItem fileExit;
	
	// View submenus
	private JMenuItem viewSeatingMap;
	private JMenuItem viewTicket;
	
	// Tickets submenus
	private JMenuItem buyTicket;
	private JMenuItem viewSoldTickets;
	private JMenuItem viewAvailableTickets;
	
	// images
	JLabel ticketboothimg;
		
	public TicketBoothGUI(String windowTitle, Ticketbooth ticketbooth) {
		super(windowTitle);
		this.ticketBooth = ticketbooth;
		
		setSize(1000,563);
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		buildGUI();
		setVisible(true);
		ticketbooth.restock();
	}
	

	private void buildGUI() {
		menuBar = new JMenuBar();
		
		// File exit
		fileMenu = new JMenu("File");		
		fileSave = new JMenuItem("Save");
		fileLoad = new JMenuItem("Load");
		
		fileExit = new JMenuItem("Exit");
		fileSave.addActionListener(new MenuListener());
		fileLoad.addActionListener(new MenuListener());
		fileExit.addActionListener(new MenuListener());
		fileMenu.add(fileSave);
		fileMenu.add(fileLoad);
		fileMenu.add(fileExit);
		// view seating/ticket information
		viewMenu = new JMenu("View");
		viewSeatingMap = new JMenuItem("Show Seating Map");
		viewSeatingMap.addActionListener(new MenuListener());
		viewTicket = new JMenuItem("View Ticket");
		viewTicket.addActionListener(new MenuListener());
		viewSoldTickets = new JMenuItem("View Sold Tickets");
		viewSoldTickets.addActionListener(new MenuListener());
		viewAvailableTickets = new JMenuItem("View Available Tickets");
		viewAvailableTickets.addActionListener(new MenuListener());
		viewMenu.add(viewSeatingMap);
		//viewMenu.add(viewTicket);
		viewMenu.add(viewAvailableTickets);
		viewMenu.add(viewSoldTickets);
		// Buy ticket
		ticketsMenu = new JMenu("Tickets");
		buyTicket = new JMenuItem("Buy Ticket");
		buyTicket.addActionListener(new MenuListener());
		ticketsMenu.add(buyTicket);
		
		menuBar.add(fileMenu);
		menuBar.add(viewMenu);
		menuBar.add(ticketsMenu);
		
		ticketboothimg = new JLabel();
		ticketboothimg.setIcon(new ImageIcon("images/ticketbooth.jpg"));
		
		add(ticketboothimg);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setJMenuBar(menuBar);
	}
	
	private class MenuListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JMenuItem source = (JMenuItem)(e.getSource());
			if (source.equals(fileSave)) {
				handleFileSave();
			}
			if (source.equals(fileLoad)) {
				handleFileLoad();
			}
			if (source.equals(fileExit)) {
				handleFileExit();
			}
			if (source.equals(viewAvailableTickets)) {
				handleViewAvailableTickets();
			}
			if (source.equals(viewSoldTickets)) {
				handleViewSoldTickets();
			}
			if (source.equals(viewSeatingMap)) {
				handleViewSeatingMap();
			}
			if (source.equals(buyTicket)) {
				handleBuyTicket();
			}
			
		}
		
		private void handleViewSoldTickets() {
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			PrintStream pstream = new PrintStream(stream);
			PrintStream stdout = System.out;
			System.setOut(pstream);
			
			for(Ticket t : ticketBooth.getSoldTickets()) {
				ticketBooth.printTicketInformation(t);
			}
			
			// Create a text pane
			JEditorPane textPane = new JEditorPane();
			textPane.setMargin(new Insets(0,20,0,0));
			textPane.setEditable(true);
			
			// Populate the text pane with the stream contents
			textPane.setText(stream.toString());
			textPane.setCaretPosition(0);
			
			// put the text pane in a scroll pane
			JScrollPane scrollPane = new JScrollPane(textPane);
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setPreferredSize(new Dimension(600, 400));
			
			// Put the scroll pane in a JFrame and show			
			JFrame frame = new JFrame("Sold Tickets");
			frame.add(scrollPane);
			frame.setSize(600, 800);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
			
			System.setOut(stdout);
		}

		private void handleViewAvailableTickets() {
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			PrintStream pstream = new PrintStream(stream);
			PrintStream stdout = System.out;
			System.setOut(pstream);
			
			for(Ticket t : ticketBooth.getAvailableTickets()) {
				ticketBooth.printTicketInformation(t);
			}
			
			// Create a text pane
			JEditorPane textPane = new JEditorPane();
			textPane.setMargin(new Insets(0,20,0,0));
			textPane.setEditable(true);
			
			// Populate the text pane with the stream contents
			textPane.setText(stream.toString());
			textPane.setCaretPosition(0);
			
			// put the text pane in a scroll pane
			JScrollPane scrollPane = new JScrollPane(textPane);
			scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scrollPane.setPreferredSize(new Dimension(600, 400));
			
			// Put the scroll pane in a JFrame and show			
			JFrame frame = new JFrame("Sold Tickets");
			frame.add(scrollPane);
			frame.setSize(600, 800);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
			
			System.setOut(stdout);
		}

		private void handleFileLoad() {
			Ticketbooth.saveData(ticketBooth);
		}

		private void handleFileSave() {
			Ticketbooth.loadData();
		}

		private void handleBuyTicket() {
			JTextField section = new JTextField(10);
			JTextField row = new JTextField(10);
			JTextField number = new JTextField(10);
			
			JPanel panel = new JPanel();
			panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
			
			panel.add(new JLabel("Section: (100-103,200-203,300-303)"));
			panel.add(section);
			
			panel.add(new JLabel("Row: (A-G)"));
			panel.add(row);
			
			panel.add(new JLabel("Number: (1-10)"));
			panel.add(number);
			
			
			JOptionPane.showConfirmDialog(null, panel, "Buy Ticket", JOptionPane.OK_CANCEL_OPTION);
			
			int section_i = Integer.getInteger((section.getText()));
			char row_c = row.getText().charAt(0);
			int number_i = Integer.getInteger(number.getText());
			
			
			
			Ticket soldTicket = ticketBooth.sellTicket(new Ticket(section_i, row_c, number_i, (section_i/100)-1));
			
			if (soldTicket == null) {
				createMessageWindow("Error", "The entered ticket is not available."); 
			}
			else {
				createMessageWindow("Success", "Ticket has been sold.");
			}
		}
		
		private void createMessageWindow(String title, String message) {
			JOptionPane.showMessageDialog(null, 
					message,
					title, 
					JOptionPane.PLAIN_MESSAGE);
			return;
		}
		
		private void handleViewSeatingMap() {
			//JPanel panel = new JPanel();
			JFrame frame = new JFrame();
			frame.setSize(1445, 800);
			
			JLabel seatingMap = new JLabel();
			seatingMap.setIcon(new ImageIcon("images/seating.jpg"));
			
			frame.add(seatingMap);
			
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setVisible(true);
		}

		private void handleFileExit() {
			System.exit(0);
		}	
	}
	
}
