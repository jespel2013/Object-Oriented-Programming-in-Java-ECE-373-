package GUI;

import locations.Ticketbooth;

public class TestTicketboothGUI {
	public static void main(String[] args) {
		// instantiate ticket booth GUI
		Ticketbooth ticketbooth = new Ticketbooth();
		TicketBoothGUI ticketBoothGUI;
		
		ticketBoothGUI = new TicketBoothGUI("Ticket Booth", ticketbooth);
		
		ticketBoothGUI.getSize();
	}
}
