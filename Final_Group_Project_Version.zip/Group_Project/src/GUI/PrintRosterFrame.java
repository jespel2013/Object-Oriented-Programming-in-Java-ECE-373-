package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import gameplay.Club;

public class PrintRosterFrame extends JFrame{
	private Club club;
	private JTextArea textArea;
	private String str;
	private JButton ok;
	
	public PrintRosterFrame(Club aClub) {
		super("Current Roster");
		club = aClub;
		
		setLayout(new FlowLayout());
		
		str = club.getTeam().printRoster();

		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setEditable(false);
		textArea.setVisible(true);
		textArea.setText(str);
		textArea.setSize(300, 200);
		
		//panel adds text area
		JPanel panel = new JPanel();
		panel.add(textArea);
		
		//adds button
		ok = new JButton("OK");
		ok.addActionListener(new ButtonListener());
		ok.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		
		panel.setBorder(BorderFactory.createEmptyBorder(0, 35,0,0));
		
		add(panel, BorderLayout.CENTER);
		add(ok, BorderLayout.SOUTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);

		
	}
	
	private class ButtonListener implements ActionListener{

		
		public void actionPerformed(ActionEvent e) {
			setVisible(false);
			dispose();
		}
		
	}
	
}
