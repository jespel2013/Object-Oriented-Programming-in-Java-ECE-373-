package GUI;

public class TestGUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AddPlayerFrame addFrame = new AddPlayerFrame();
	}

}
