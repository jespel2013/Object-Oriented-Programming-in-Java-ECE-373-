package GUI;

import gameplay.Club;
import gameplay.Game;
import gameplay.Team;
import humans.GeneralManager;
import humans.Player;
import humans.Spectator;
import locations.Ticketbooth;

public class TestClubGUI {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		Club club = new Club();
		club.getTeam().setTeamName("Wildcats");
		club.setStadium("Hi Corbett Field");
		
		
		//team
		Team aTeam = new Team();
		Team anOpponent = new Team();
		anOpponent.setTeamName("The Enemy");
		GeneralManager gm = new GeneralManager();
		gm.setName("Our General Manager");
		aTeam.setTeamName("OurTeam");
		gm.setSalary(200000.0);
		gm.setNumber(0);
		gm.setTeam(aTeam);
		aTeam.setGeneralManager(gm);
		club.setTeam(aTeam);
		
		
		
		String[] names =  {"David","Jesse","Alex","Carlos","Carlos II","Stevie Ray", "Flapjack", "Stew", "Tangerine"};
		
		for(int plyr = 1; plyr < 10; plyr++) {
			Player tempP = new Player();
			tempP.setNumber(plyr + 5*plyr); //a number
			tempP.setPosition(plyr);
			tempP.setTenure(2);
			tempP.setName(names[plyr-1]);
			tempP.setSalary((double)plyr*1000000.0);
			try {
			gm.addPlayer(tempP);
			}
			catch(Exception e){
				System.out.println(e);
			}
		}
		
		club.getOpponents().add(anOpponent);
		try {
			club.scheduleGame(new Game(102, anOpponent));
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		//locations
		Ticketbooth ticketbooth = new Ticketbooth();
		ticketbooth.restock();
		
		Spectator s1 = new Spectator();
		
		StartGUI start = new StartGUI(club);
	}

}
