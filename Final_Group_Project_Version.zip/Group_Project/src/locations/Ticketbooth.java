package locations;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import gameplay.Club;
import humans.Spectator;

public class Ticketbooth extends Store implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6333725263637281970L;
	private ArrayList<Ticket> availableTickets;
	private ArrayList<Ticket> soldTickets;
	private ArrayList<Spectator> spectatorList;
	
	public Ticketbooth () {
		super();
		availableTickets = new ArrayList<Ticket>();
		soldTickets = new ArrayList<Ticket>();
		spectatorList = new ArrayList<Spectator>();
	}
	
	// * buyTicket * //
		/*
		 * Procedure:	1. Get list of available seats (print or show in gui)
		 * 				2. Get seat choice from spectator
		 * 				3. If sufficient funds, take funds, return ticket to spectator and mark ticket as sold
		 * Exceptions: 	TicketsSoldOut
		 * 				InsufficientFunds
		 */
	
	public ArrayList<Ticket> getAvailableTickets() {
		return availableTickets;
	}
	public ArrayList<Ticket> getSoldTickets() {
		return soldTickets;
	}
	
	public void printTicketInformation(Ticket t) {
		System.out.println(
				  "Section: " + t.getSection()
				+ "\tRow: " + t.getRow()
				+ "\tSeat: " + t.getNumber()
				+ "\tPrice: " + t.getSellPrice()
				);
	}
	
	public ArrayList<Ticket> showTickets() throws Exception {
		if(availableTickets.size() == 0) {
			throw new Exception("TicketsSoldOut");
		}
		
		return availableTickets;
	}
	
	
	public void buyItem(Item item, Spectator spectator) throws Exception{
		if(!availableTickets.contains(item)) {
			throw new Exception("ItemNotInStock");
		}
		spectator.setTicket((Ticket)item);
	}
	
	
	private Ticket findTicket(int section, char row, int number) {
		for (Ticket t : availableTickets) {
			if(t.getRow() == row &&
					t.getSection() == section &&
					t.getNumber() == number
					)
				return t;
		}
		return null;
	}
	
	public Ticket sellTicket(Ticket t) {
		Ticket ticket = findTicket(t.getSection(), t.getRow(), t.getNumber());
		if (ticket != null) {
			super.addRevenue(ticket.getSellPrice());
			soldTickets.add(ticket);
			availableTickets.remove(ticket);
			return ticket;
		}
		
		System.out.println("Ticket is not available.");		
		return null;
	}
	
	public void restock() {
		availableTickets.clear();
		soldTickets.clear();
		
		for(int section = 100; section < 104; section++) {
			for(char row = 'A'; row < 'H'; row++) {
				for(int seat = 1; seat < 11; seat++) {
					Ticket newTicket = new Ticket(section, row, seat, 0);
					newTicket.setSellPrice(100);
					availableTickets.add(newTicket);
				}
			}
		}
		
		for(int section = 200; section < 204; section++) {
			for(char row = 'A'; row < 'H'; row++) {
				for(int seat = 1; seat < 11; seat++) {
					Ticket newTicket = new Ticket(section, row, seat, 1);
					newTicket.setSellPrice(50);
					availableTickets.add(newTicket);
				}
			}
		}
		
		for(int section = 300; section < 304; section++) {
			for(char row = 'A'; row < 'H'; row++) {
				for(int seat = 1; seat < 11; seat++) {
					Ticket newTicket = new Ticket(section, row, seat, 2);
					newTicket.setSellPrice(25);
					availableTickets.add(newTicket);
				}
			}
		}
	}
	
	public ArrayList<Spectator> getSpectatorList(){
		return spectatorList;
	}
	
public static void saveData(Ticketbooth ticketbooth){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(ticketbooth);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Ticketbooth loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Ticketbooth ticketbooth= null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			ticketbooth = (Ticketbooth) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return ticketbooth;
	}
}
