package locations;

import java.io.Serializable;
import java.util.ArrayList;

import humans.Spectator;
import humans.Vendor;

public abstract class Store implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5172367836443409463L;
	private double costs;
	private double revenue;
	private ArrayList<Vendor> workers;
	
	public Store() {
		costs = 0.0;
		revenue = 0.0;
		workers = new ArrayList<Vendor>();
	}
	
	public double getCosts() {
		return costs;
	}
	
	public void setCosts(double costs) {
		this.costs = costs;
	}

	public void addCosts(double amount) {
		this.costs += costs;
	}

	public double getRevenue() {
		return revenue;
	}
	
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}

	public void addRevenue(double amount) {
		this.revenue += amount;
	}
	
	public double calculateProfit() {
		return (revenue - costs);
	}
	
	public void addWorker(Vendor vendor) {
		workers.add(vendor);
		vendor.setStore(this);
	}
	
	public ArrayList<Vendor> getWorkers() {
		return workers;
	}
	
	public abstract void restock();

	public void addTenure() {
		for(Vendor vendor : workers) {
			vendor.setTenure(vendor.getTenure() + 1);
		}
		
	}
	
	public abstract void buyItem(Item item, Spectator spectator) throws Exception;
}
