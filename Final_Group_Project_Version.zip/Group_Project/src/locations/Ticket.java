package locations;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Ticket extends Item implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8856183331667657174L;
	private int section;
	private char row;
	private int number;
	private int tier;
	private Boolean available;
	
	private String[] ticketTier = {
		"high",
		"med",
		"low"
	};
	
	public Ticket(int section, char row, int number, int tier) {
		super();
		this.section = section;
		this.row = row;
		this.number = number;
		this.available = true;
		this.tier = tier;
	}

	public int getSection() {
		return section;
	}

	public void setSection(int section) {
		this.section = section;
	}

	public char getRow() {
		return row;
	}

	public void setRow(char row) {
		this.row = row;
	}

	public int getNumber() {
		return number;
	}
	
	public void setNumber(int number) {
		this.number = number;
	}
	
	public Boolean isAvailable() {
		return available;
	}

	public String getTier() {
		return ticketTier[tier];
	}
	public int getTier_int() {
		return tier;
	}
	
public static void saveData(Ticket ticket){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(ticket);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Ticket loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Ticket ticket=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			ticket = (Ticket) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return ticket;
	}
	
}
