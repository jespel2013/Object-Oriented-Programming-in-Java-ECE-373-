package locations;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


public class Item implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 9186429116707173726L;
	private String name;
	private int quantity;
	private int maxStock;
	private double buyPrice;
	private double sellPrice;
	
	public Item() {
		name = " ";
		quantity = 0;
		maxStock = 0;
		buyPrice = 0.0;
		sellPrice = 0.0;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getMaxStock() {
		return maxStock;
	}
	
	public void setMaxStock(int maxStock) {
		this.maxStock = maxStock;
	}
	
	public double getBuyPrice() {
		return buyPrice;
	}
	
	public void setBuyPrice(double buyPrice) {
		this.buyPrice = buyPrice;
	}
	
	public double getSellPrice() {
		return sellPrice;
	}
	
	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}
	
public static void saveData(Item item){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(item);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Item loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Item item=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			item = (Item) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return item;
	}
	
}
