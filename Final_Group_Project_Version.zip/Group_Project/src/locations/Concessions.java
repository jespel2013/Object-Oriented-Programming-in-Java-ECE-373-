package locations;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import humans.Spectator;

public class Concessions extends Store implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7928826316492624902L;
	private ArrayList<Item> inventory;
	
	public Concessions() {
		super();
		inventory = new ArrayList<Item>();
	}
	
	public void addItem(Item newItem) {
		inventory.add(newItem);
	}
	
	
	public void buyItem(Item item, Spectator spectator) throws Exception{
		for(Item stock : inventory) {
			if(stock.getName().equals(item.getName())) {
				if(stock.getQuantity() == 0) {
					throw new Exception("ItemOutOfStock");
				}
				
				else if(stock.getQuantity() < item.getQuantity()) {
					throw new Exception("ItemLowOnStock");
				}
				
				else {
					stock.setQuantity(stock.getQuantity() - item.getQuantity());
					this.addRevenue(item.getQuantity() * stock.getSellPrice());
					spectator.addItemBought(item);
					return;
				}
			}
		}
		
		throw new Exception("ItemNotInStock");
	}
	
	public ArrayList<Item> getInventory() {
		return inventory;
	}
	
	public void restock() {
		for(int i = 0; i < inventory.size(); i++) {
			Item currItem = inventory.get(i);
			addCosts(currItem.getBuyPrice() * (currItem.getMaxStock() - currItem.getQuantity()));
			currItem.setQuantity(currItem.getMaxStock());
		}
	}
	
	public Item findItem(String name) {
		for(int itemI = 0; itemI < inventory.size(); itemI++) {
			if(inventory.get(itemI).getName().equals(name)) {
				return inventory.get(itemI);
			}
		}
		
		return null;
	}
	
public static void saveData(Concessions concessions){
		
		
		FileOutputStream fileOut = null;
		ObjectOutputStream objOut= null;

		try 
		{
			fileOut = new FileOutputStream( "club.ser" );		//the University object makes its way to serial data in the file university.ser
			objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(concessions);
			objOut.close();
			fileOut.close();
	     }	
		
		catch(IOException i)
	    {
			i.printStackTrace();
	    }		
 	}

	public static Concessions loadData()
	{	
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		Concessions concessions=null;
			
		try
		{
			fileIn = new FileInputStream("club.ser");
			objIn = new ObjectInputStream(fileIn);
			concessions = (Concessions) objIn.readObject();
			objIn.close();
			fileIn.close();
		}
		catch(IOException i)
		{
			i.printStackTrace();
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}  
		return concessions;
	}
}
