package test;

import locations.*;


import humans.*;

public class TestLocations {
	
	public static void main(String[] args) {
		Ticketbooth ticketbooth = new Ticketbooth();
		ticketbooth.restock();
		
		
		//TEST try selling ticket that doesn't exist in AvailableTickets
		Ticket t1 = new Ticket(99, 'A', 4, 0);
		Spectator s1 = new Spectator();
		try {
			s1.buyItem(t1, ticketbooth);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		//TEST sell all tickets then attempt to show available tickets
		while (ticketbooth.getAvailableTickets().size() > 0) {
			try {
				s1.buyItem(ticketbooth.showTickets().get(0), ticketbooth);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		try {
			s1.showTickets(ticketbooth);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Concessions concessions = new Concessions();
		Item hotdog = new Item();
		hotdog.setName("hot dog");
		hotdog.setQuantity(0);
		concessions.addItem(hotdog);
		
		//Test try selling item out of stock
		try {
			s1.buyItem(hotdog, concessions);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Item pretzel = new Item();
		pretzel.setName("pretzel");
		pretzel.setQuantity(5);
		//Test try selling item not in inventory		
		try {
			s1.buyItem(pretzel, concessions);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		TeamStore teamstore = new TeamStore();
		Item jersey = new Item();
		jersey.setName("jersey");
		jersey.setQuantity(0);
		teamstore.addItem(jersey);
		
		//Test try selling item out of stock
		try {
			s1.buyItem(jersey, teamstore);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Item baseballCap = new Item();
		baseballCap.setName("baseball cap");
		baseballCap.setQuantity(5);
		//Test try selling item not in inventory		
		try {
			s1.buyItem(baseballCap, teamstore);
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
	
	
}
