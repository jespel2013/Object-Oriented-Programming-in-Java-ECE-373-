package test;

import gameplay.Club;
import gameplay.Game;
import gameplay.Team;

public class TestGameplay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Club club = new Club();
		
		club.setStadium("Proving Ground");
		Team opponent1 = new Team();
		club.getOpponents().add(opponent1);
		
		//TEST starting a game with no scheduled games:
		try {
			club.startGame();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		//TEST adding game with negative schedule
		Game g1 = new Game(-1, opponent1);
		try {
			club.scheduleGame(g1);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		//TEST adding game with invalid time
		Game g2 = new Game(025, opponent1);
		try {
			club.scheduleGame(g2);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		//TEST adding game with invalid date
		Game g3 = new Game(3205, opponent1);
		try {
			club.scheduleGame(g3);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		//TEST adding game with invalid opponent
		Team opponent2 = new Team();
		Game g4 = new Game(2421, opponent2);
		try {
			club.scheduleGame(g4);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		//TEST scheduling games at the same time
		Game g5 = new Game(2421, opponent1);
		Game g6 = new Game(2421, opponent1);
		try {
			club.scheduleGame(g5);
			club.scheduleGame(g6);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		//TEST starting a game while one is already playing
		try {
			club.startGame();
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			club.startGame();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		//TEST ending a game while score is tied
		try {
			club.endGame();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		//TEST ending a game with uneven score
		try {
			club.incrementHome();
			club.endGame();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		//TEST changing scores with no game playing
		try {
			club.incrementHome();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		try {
			club.incrementAway();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		try {
			club.decrementHome();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		try {
			club.decrementAway();
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}
