package test;

import java.util.ArrayList;

import gameplay.Club;
import gameplay.Team;
import humans.GeneralManager;
import humans.Player;

public class TestHumans {
	public static void main(String[] args) throws Exception {
		
		//Setting up club to test humans
		
		Club myClub = new Club();
		myClub.setStadium("Stadium Field");
		Team aTeam = new Team();
		GeneralManager gm = new GeneralManager();
		gm.setName("Our General Manager");
		aTeam.setTeamName("OurTeam");
		gm.setSalary(200000.0);
		gm.setNumber(0);
		gm.setTeam(aTeam);
		aTeam.setGeneralManager(gm);
		myClub.setTeam(aTeam);
		
		//Add Player Exceptions
		//Player is already on the team
		Player p1 = new Player();
		Player p2 = new Player();
		Player p3 = new Player();
		Player p4 = new Player();
		Player p5 = new Player();
		p1.setName("Don Donaldson");
		p1.setPosition(9);
		p1.setNumber(70-1);
		p2.setName("Jeff Jefferson");
		p2.setPosition(7);
		p2.setNumber(70-1);
		p3.setName("Jeff Jefferson");
		p3.setPosition(7);
		p3.setNumber(69);
		p4.setName("Rich Richardson");
		p4.setPosition(1);
		p4.setNumber(-1);
		p5.setName("Steve Stevenson");
		p5.setPosition(3);
		p5.setNumber(101);
		
		
		System.out.println("Test addPlayer Exceptions\n");
		//Player is already on the team
		try {
			gm.addPlayer(p2);
			gm.addPlayer(p3);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		//Jersey Number already taken
		try {
			gm.addPlayer(p2);
			gm.addPlayer(p1);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		//Jersey number is too big
		try {
			gm.addPlayer(p5);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		//Jersey number is negative
		try {
			gm.addPlayer(p4);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		String[] names =  {"David","Jesse","Alex","Carlos","Carlos II","Stevie Ray", "Flapjack", "Stew", "Tangerine"};
		
		System.out.println("\nTest addPlayer Functionality\n");
		//reset roster
		myClub.getTeam().setRoster(new ArrayList<Player>());
		//add generic Players
		for(int plyr = 1; plyr < 10; plyr++) {
			Player tempP = new Player();
			tempP.setNumber(plyr + 5*plyr); //a number
			tempP.setPosition(plyr);
			tempP.setTenure(2);
			tempP.setName(names[plyr-1]);
			tempP.setSalary((double)plyr*1000000.0);
			gm.addPlayer(tempP);
		}
		//print out generic players
		
		System.out.println("Name: \t      Jersey: \t Position:");
		for(Player p:myClub.getTeam().getRoster()) {
			System.out.println(p.getName() + "\t\t" + p.getJerseyNum() + "\t\t" + p.getPosition());
		}
		
		
	}
}
